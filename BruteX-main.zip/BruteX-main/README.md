# BruteX
BruteX is A bruteForce attacking tool
### Features Of BruteX:
+ You can bruteforce attack on your victim's Instagram, Facebook and Email ID with 100 password/second you can add your own custom password list and this tool also has password list, so If you don't have your own password list then it's ok don't worry you can use auto attack function (In this function you don't need your own password list).

## Attack Type
#### BruteForce Attack
+ Auto Attack
+ Manual Attack

#### python or python3 supporting

### Tested on:
+ Termux
+ ~Linux~
### Available for:
+ Termux
+ ~Linux~

### About Next Update
+ BruteX will available for all operating system in next update.

### Installation:
+ ```apt update```
+ ```apt upgrade```
+ ```apt install git -y```
+ ```git clone https://github.com/MrHacker-X/BruteX.git/```
+ ```cd BruteX```
+ ```chmod +x *```
+ ```bash setup.sh``` or ```./setup.sh```

#### Now wait for installation of the tool, If your setup is completed then you can run it by this
``` python brutex.py ``` or ``` python3 brutex.py ```
## Single line command:
```
apt update && apt upgrade && apt install git -y && git clone https://github.com/MrHacker-X/BruteX.git/ && cd BruteX && chmod +x * && bash setup.sh && python brutex.py
```

## Screenshot
### Main menu
![photo](https://raw.githubusercontent.com/MrHacker-X/BruteX/main/.img/main_menu.jpg)

### Input passwordlist
![photo](https://raw.githubusercontent.com/MrHacker-X/BruteX/main/.img/pass.jpg)

### Setup
![photo](https://raw.githubusercontent.com/MrHacker-X/BruteX/main/.img/setup.jpg)

### Attacking
![photo](https://raw.githubusercontent.com/MrHacker-X/BruteX/main/.img/attacking.jpg)

## Note :-
+ Run ```tor``` in another session when you're work with Instagram hack
+ Simply type ``` tor ``` and enter for run it

#### Created By : MrHacker-X

<h3><b><i>📡 Connect with us :</i></b></h3>
<a href="https://github.com/MrHacker-X/"><img align="left" title="Github" alt="Github" width="30px" src="https://raw.githubusercontent.com/MrHacker-X/MrHacker-X/main/assets/github.png" /></a>
<a href="https://instagram.com/hackerxmr/"><img align="left" title="Instagram" alt="Instagram" width="30px" src="https://github.com/MrHacker-X/MrHacker-X/blob/main/assets/instagram.png" /></a>
<a href="https://t.me/mrhackersx/"><img align="left" title="Telegram" alt="Telegram" width="30px" src="https://github.com/MrHacker-X/MrHacker-X/blob/main/assets/telegram.png" /></a>
<a href="https://youtube.com/c/Sololex//"><img align="left" title="YouTube" alt="YouTube" width="30px" src="https://github.com/MrHacker-X/MrHacker-X/blob/main/assets/youtube.png" /></a>
